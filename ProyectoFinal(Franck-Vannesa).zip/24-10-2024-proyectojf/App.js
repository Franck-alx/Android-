import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Alert, StyleSheet } from 'react-native';

const Conversor = () => {
  const [cantidadDolares, setCantidadDolares] = useState('');
  const [cantidadQuetzales, setCantidadQuetzales] = useState('');
  const [cantidadBitcoin, setCantidadBitcoin] = useState('');
  const [equivalenteQuetzales, setEquivalenteQuetzales] = useState('');
  const [equivalenteDolares, setEquivalenteDolares] = useState('');
  const [equivalenteBitcoin, setEquivalenteBitcoin] = useState('');
  const [tipoCambio, setTipoCambio] = useState(0);
  const [tipoCambioBTC, setTipoCambioBTC] = useState(0);
  const [error, setError] = useState('');

  // Función para obtener el tipo de cambio de USD a GTQ
  const obtenerTipoCambioUSD_GTQ = async () => {
    try {
      const respuesta = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
      const datos = await respuesta.json();
      
      if (datos && datos.rates && datos.rates.GTQ) {
        setTipoCambio(datos.rates.GTQ);
        setError('');
      } else {
        setError('Error: tipo de cambio no encontrado en la respuesta.');
      }
    } catch (error) {
      setError('Error al obtener el tipo de cambio de USD a GTQ');
      console.error('Error al obtener el tipo de cambio:', error);
    }
  };

  // Función para obtener el tipo de cambio de BTC a USD
  const obtenerTipoCambioBTC = async () => {
    try {
      const respuesta = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd');
      const datos = await respuesta.json();
      
      if (datos && datos.bitcoin && datos.bitcoin.usd) {
        setTipoCambioBTC(datos.bitcoin.usd);
        setError('');
      } else {
        setError('Error: tipo de cambio BTC a USD no encontrado en la respuesta.');
      }
    } catch (error) {
      setError('Error al obtener el tipo de cambio de BTC a USD');
      console.error('Error al obtener el tipo de cambio:', error);
    }
  };

  useEffect(() => {
    obtenerTipoCambioUSD_GTQ();
    obtenerTipoCambioBTC();
  }, []);

  // Funciones de conversión
  const convertirDesdeQuetzales = (valorEnQuetzales) => {
    const valorEnUSD = parseFloat(valorEnQuetzales) / tipoCambio;
    setEquivalenteDolares(valorEnUSD.toFixed(2));
    setEquivalenteBitcoin((valorEnUSD / tipoCambioBTC).toFixed(8));
    setEquivalenteQuetzales(valorEnQuetzales);
  };

  const convertirDesdeDolares = (valorEnDolares) => {
    const valorEnGTQ = parseFloat(valorEnDolares) * tipoCambio;
    setEquivalenteQuetzales(valorEnGTQ.toFixed(2));
    setEquivalenteBitcoin((parseFloat(valorEnDolares) / tipoCambioBTC).toFixed(8));
    setEquivalenteDolares(valorEnDolares);
  };

  const convertirDesdeBitcoin = (valorEnBitcoin) => {
    const valorEnUSD = parseFloat(valorEnBitcoin) * tipoCambioBTC;
    setEquivalenteDolares(valorEnUSD.toFixed(2));
    setEquivalenteQuetzales((valorEnUSD * tipoCambio).toFixed(2));
    setEquivalenteBitcoin(valorEnBitcoin);
  };

  // Manejar cambios en cada campo de entrada
  const handleChangeQuetzales = (text) => {
    setCantidadQuetzales(text);
    setCantidadDolares('');
    setCantidadBitcoin('');
    if (text) convertirDesdeQuetzales(text);
  };

  const handleChangeDolares = (text) => {
    setCantidadDolares(text);
    setCantidadQuetzales('');
    setCantidadBitcoin('');
    if (text) convertirDesdeDolares(text);
  };

  const handleChangeBitcoin = (text) => {
    setCantidadBitcoin(text);
    setCantidadDolares('');
    setCantidadQuetzales('');
    if (text) convertirDesdeBitcoin(text);
  };

  return (
    <View style={styles.container}>
      {error ? <Text style={{ color: 'red' }}>{error}</Text> : null}

      <Text style={styles.Text}>Tipo de cambio actual (USD a GTQ): {tipoCambio}</Text>
      <Text style={styles.Text}>Tipo de cambio actual (BTC a GTQ): {(tipoCambioBTC * tipoCambio).toFixed(2)}</Text>
      <Text style={styles.Text}>Tipo de cambio actual (BTC a USD): {tipoCambioBTC}</Text>

      <TextInput
        placeholder="entrada en Quetzales"
        value={cantidadQuetzales}
        onChangeText={handleChangeQuetzales}
        keyboardType="numeric"
        style={styles.input}
      />

      <TextInput
        placeholder="entrada en Dólares"
        value={cantidadDolares}
        onChangeText={handleChangeDolares}
        keyboardType="numeric"
        style={styles.input}
      />

 
      <TextInput
        placeholder="entrada en Bitcoin"
        value={cantidadBitcoin}
        onChangeText={handleChangeBitcoin}
        keyboardType="numeric"
        style={styles.input}
      />

      {/* Resultados al final */}
      <Text style={styles.resultText}>Equivalente en Quetzales: {equivalenteQuetzales}</Text>
      <Text style={styles.resultText}>Equivalente en Dólares: {equivalenteDolares}</Text>
      <Text style={styles.resultText}>Equivalente en Bitcoin: {equivalenteBitcoin}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
  },
  infoText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#333',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 15,
    paddingHorizontal: 10,
  },
  resultText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 15,
  },
});

export default Conversor;
